

   ____        _           _              __    
  / ___| _ __ | | __ _ ___| |__     ___  / _|   
  \___ \| '_ \| |/ _` / __| '_ \   / _ \| |_    
   ___) | |_) | | (_| \__ \ | | | | (_) |  _|   
 _|____/| .__/|_|\__,_|___/_| |_|_ \___/|_|     
| __ )  |_|| |_ __ _ / _ \ _ __ | (_)_ __   ___ 
|  _ \ / _ \ __/ _` | | | | '_ \| | | '_ \ / _ \
| |_) |  __/ || (_| | |_| | | | | | | | | |  __/
|____/ \___|\__\__,_|\___/|_| |_|_|_|_| |_|\___|



==============================================================================
SPLASH OF BETAONLINE
==============================================================================

Name: Splash of BetaOnline
Game version: Beta 1.7.3
Type: Jar mod
(Archived June 2024 by 44cckw)

The Splash of BetaOnline is a jar mod that adds custom splash messages to Minecraft's main menu. These splash messages contain numerous references and quotes relevant to BetaOnline.

Versions included in this archive:

• Splash of BetaOnline U_01 - September 30th, 2022.
• Splash of BetaOnline U_02 - September 30th, 2022.
• Splash of BetaOnline U_05 - October 2nd, 2022.
• Splash of BetaOnline U_06 - October 6th, 2022.
• Splash of BetaOnline U_07 - October 6th, 2022.
• Splash of BetaOnline U_08 - October 10th, 2022.
• Splash of BetaOnline U_09 - October 10th, 2022.
• Splash of BetaOnline U_12 - October 10th, 2022.
• Splash of BetaOnline U_13 - October 10th, 2022.

Contact 44cckw on Discord if you have the files for the "lost" versions.

==============================================================================
CONTRIBUTORS
==============================================================================

• FinsCon
• raddicted
• shigaduhshay
...and various other players
